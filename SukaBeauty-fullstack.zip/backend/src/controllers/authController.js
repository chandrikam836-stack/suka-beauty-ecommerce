const bcrypt = require("bcryptjs");
const crypto = require("crypto");
const { User } = require("../models");
const generateToken = require("../utils/generateToken");
const generateOTP = require("../utils/generateOTP");
const { sendMail } = require("../config/mailer");

// ---- REGISTER ----
exports.register = async (req, res, next) => {
  try {
    const { name, email, password, phone } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ message: "Name, email and password are required" });
    }

    const existing = await User.findOne({ where: { email } });
    if (existing) return res.status(409).json({ message: "Email already registered" });

    const hashed = await bcrypt.hash(password, 10);
    const otp = generateOTP();

    const user = await User.create({
      name,
      email,
      phone,
      password: hashed,
      otp,
      otpExpiry: new Date(Date.now() + 10 * 60 * 1000), // 10 min
    });

    await sendMail({
      to: email,
      subject: "Verify your Suka Beauty account",
      html: `<h2>Welcome to Suka Beauty, ${name}!</h2><p>Your verification code is:</p><h1>${otp}</h1><p>This code expires in 10 minutes.</p>`,
    });

    res.status(201).json({
      message: "Registered successfully. Check your email for the OTP to verify your account.",
      userId: user.id,
      email: user.email,
    });
  } catch (err) {
    next(err);
  }
};

// ---- VERIFY OTP ----
exports.verifyOtp = async (req, res, next) => {
  try {
    const { email, otp } = req.body;
    const user = await User.findOne({ where: { email } });
    if (!user) return res.status(404).json({ message: "User not found" });
    if (user.isVerified) return res.status(400).json({ message: "Account already verified" });

    if (user.otp !== otp || !user.otpExpiry || new Date() > user.otpExpiry) {
      return res.status(400).json({ message: "Invalid or expired OTP" });
    }

    user.isVerified = true;
    user.otp = null;
    user.otpExpiry = null;
    await user.save();

    const token = generateToken(user);
    res.json({
      message: "Account verified successfully",
      token,
      user: { id: user.id, name: user.name, email: user.email, role: user.role },
    });
  } catch (err) {
    next(err);
  }
};

// ---- RESEND OTP ----
exports.resendOtp = async (req, res, next) => {
  try {
    const { email } = req.body;
    const user = await User.findOne({ where: { email } });
    if (!user) return res.status(404).json({ message: "User not found" });
    if (user.isVerified) return res.status(400).json({ message: "Account already verified" });

    const otp = generateOTP();
    user.otp = otp;
    user.otpExpiry = new Date(Date.now() + 10 * 60 * 1000);
    await user.save();

    await sendMail({
      to: email,
      subject: "Your new Suka Beauty verification code",
      html: `<h1>${otp}</h1><p>This code expires in 10 minutes.</p>`,
    });

    res.json({ message: "New OTP sent to your email" });
  } catch (err) {
    next(err);
  }
};

// ---- LOGIN ----
exports.login = async (req, res, next) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ message: "Email and password required" });

    const user = await User.findOne({ where: { email } });
    if (!user) return res.status(401).json({ message: "Invalid email or password" });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(401).json({ message: "Invalid email or password" });

    if (!user.isVerified) {
      return res.status(403).json({ message: "Please verify your email with the OTP sent to you", needsVerification: true, email: user.email });
    }

    const token = generateToken(user);
    res.json({
      message: "Login successful",
      token,
      user: { id: user.id, name: user.name, email: user.email, role: user.role },
    });
  } catch (err) {
    next(err);
  }
};

// ---- FORGOT PASSWORD ----
exports.forgotPassword = async (req, res, next) => {
  try {
    const { email } = req.body;
    const user = await User.findOne({ where: { email } });
    // Respond the same way whether or not user exists (avoid email enumeration)
    if (!user) return res.json({ message: "If that email exists, a reset link has been sent" });

    const resetToken = crypto.randomBytes(32).toString("hex");
    user.resetToken = resetToken;
    user.resetTokenExpiry = new Date(Date.now() + 30 * 60 * 1000); // 30 min
    await user.save();

    const resetUrl = `${process.env.CLIENT_URL}/reset-password.html?token=${resetToken}&email=${encodeURIComponent(email)}`;
    await sendMail({
      to: email,
      subject: "Reset your Suka Beauty password",
      html: `<p>Click below to reset your password (valid for 30 minutes):</p><a href="${resetUrl}">${resetUrl}</a>`,
    });

    res.json({ message: "If that email exists, a reset link has been sent" });
  } catch (err) {
    next(err);
  }
};

// ---- RESET PASSWORD ----
exports.resetPassword = async (req, res, next) => {
  try {
    const { email, token, newPassword } = req.body;
    const user = await User.findOne({ where: { email } });
    if (!user || user.resetToken !== token || !user.resetTokenExpiry || new Date() > user.resetTokenExpiry) {
      return res.status(400).json({ message: "Invalid or expired reset link" });
    }

    user.password = await bcrypt.hash(newPassword, 10);
    user.resetToken = null;
    user.resetTokenExpiry = null;
    await user.save();

    res.json({ message: "Password reset successful. You can now log in." });
  } catch (err) {
    next(err);
  }
};

// ---- GET CURRENT USER ----
exports.getMe = async (req, res) => {
  const { id, name, email, phone, role } = req.user;
  res.json({ id, name, email, phone, role });
};
